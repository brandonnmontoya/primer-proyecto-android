package com.example.primerproyecto;

import android.app.Activity;
import android.os.Bundle;
import android.content.res.Configuration;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import android.util.TypedValue;
import java.util.Locale;

public class MainActivity extends Activity {
    private String selectedLanguage = "es";
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showWelcome();
    }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private void applyLanguage(String language) {
        selectedLanguage = language;
        Locale locale = new Locale(language);
        Locale.setDefault(locale);
        Configuration config = new Configuration(getResources().getConfiguration());
        config.setLocale(locale);
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
        showWelcome();
    }
    private void showWelcome() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setBackgroundResource(com.example.primerproyecto.R.drawable.welcome_background);
        setContentView(root);

        TextView title = new TextView(this);
        title.setText(getString(R.string.welcome));
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, 0, 2f);
        root.addView(title, titleParams);

        Button enter = new Button(this);
        enter.setText(getString(R.string.enter));
        LinearLayout.LayoutParams enterParams = new LinearLayout.LayoutParams(-2, -2);
        enterParams.topMargin = dp(8);
        root.addView(enter, enterParams);
        enter.setOnClickListener(v -> Toast.makeText(this, getString(R.string.enter_message), Toast.LENGTH_SHORT).show());

        TextView languageLabel = new TextView(this);
        languageLabel.setText(getString(R.string.choose_language));
        languageLabel.setTextColor(Color.WHITE);
        languageLabel.setTextSize(16);
        languageLabel.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        root.addView(languageLabel, labelParams);

        LinearLayout languages = new LinearLayout(this);
        languages.setGravity(Gravity.CENTER);
        languages.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(languages, new LinearLayout.LayoutParams(-1, -2));
        String[] codes = {"es","en","fr","de"};
        String[] labels = {"Español","English","Français","Deutsch"};
        for (int i=0;i<codes.length;i++) {
            final String code = codes[i];
            Button b = new Button(this);
            b.setText(labels[i]);
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            b.setPadding(dp(4),0,dp(4),0);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
            p.setMargins(dp(2),0,dp(2),0);
            languages.addView(b,p);
            b.setOnClickListener(v -> applyLanguage(code));
        }
    }
}
