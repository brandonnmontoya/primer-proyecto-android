# Mi primer proyecto Android

Proyecto Android nativo en Java inspirado en el PDF de referencia.

## Incluye
- Recursos de idioma: español (predeterminado), inglés, francés y alemán.
- Selector visible para cambiar entre los cuatro idiomas sin salir de la pantalla.
- Fondo extraído de la imagen del PDF y recurso `welcome_background.9.png` de tipo Nine-Patch.
- Diseño adaptable: usa `dp`/`sp`, `LinearLayout` con pesos y permite orientación vertical/horizontal y distintos tamaños.
- Proyecto para abrir directamente con Android Studio.

## Abrir
1. Descomprime el ZIP.
2. Android Studio → **Open** → selecciona la carpeta `PrimerProyectoAndroid`.
3. Espera la sincronización de Gradle y ejecuta en un emulador o dispositivo.

Si Android Studio solicita instalar Android SDK Platform 35, acepta la instalación.
